"""
Problem3.py
A reproduction of the numpy.linalg.inv routine.

Author: Your Favorite Python instructors
Contact: ucbpythonclass+seminar@gmail.com
"""

import numpy as np
import numpy.linalg as linalg

def my_matrixinv(m):

    """A clone of the numpy.linalg.inv routine.  Should return the inverse
       of a matrix if that matrix invertible, else raise the LinAlg 
       exception (or some other indication that the matrix could not 
       be inverted."""

    # First off, need a square matrix 
    if (m.ndim != 2) or (m.shape[0] != m.shape[1]):
        raise linalg.LinAlgError

    # Check to see if the determinant is zero.  If yes, raise LinAlg exception
    if (linalg.det(m) == 0):
        raise linalg.LinAlgError

    # Create a new matrix, appending identify matrix onto old one
    # Note that it is quite important the dtype be set to float (or something
    # else sensible.  If the dtype is "int", division will cause big
    # problems with the inversion
    h, w = m.shape
    m2 = np.empty(shape=(h, 2*w), dtype="float32")
    m2[:,:w] = m
    m2[:,w:] = np.eye(h)

    # Put this matrix in reduced row echelon form
    m2r = rref(m2)

    # Grab the second half
    minv = m2r[:,w:]

    return minv

def rref(m2):

    """Given a matrix, return that matrix in reduced row echelon form
       using Gauss-Jordan elimination.  For algorithm, see:
       http://en.wikipedia.org/wiki/Reduced_row_echelon_form"""

    lead = 0
    h,w = m2.shape

    for r in range(h):
        if w <= lead:
            return m2
        i = r
        while m2[i,lead] == 0:
            i += 1
            if h == i:
                i = r
                lead += 1
                if w == lead:
                    return m2
        if i != r:
            temp = m2[i,]
            m2[i,] = m2[r,]
            m2[r,] = temp
        m2[r,] /= m2[r, lead]
        for i in range(h):
            if i != r:
                m2[i,] -= m2[r,] * m2[i,lead]
        lead += 1

    return m2

def tests():

    """A few test cases to see if the function works properly"""

    # Should raise an exception here (or return some kind of error
    # message since we are trying to invert a non-square matrix
    try:
        my_matrixinv(np.array([[1, 2, 3], [4, 5, 6]]))

    # Should raise an exception (or return some kind of error message)
    # here since the matrix is not invertible
        my_matrixinv(np.array([[1, 0], [0, -1]]))

    except linalg.LinAlgError:
        print "Properly handled exceptions"
    
    # Test floating point first
    t1 = np.array([[1.0, 2.0], [3.0, 4.0]])
    if (np.abs((my_matrixinv(t1) - linalg.inv(t1))) < 1e-10).all():
        print "Test 1 looks good!"
    else:
        print "Uh oh, I think there is a problem!"    

    # This should test inversion of integeter matrices
    t2 = np.array([[1, 2], [3, 4]])
    if (np.abs((my_matrixinv(t2) - linalg.inv(t2))) < 1e-10).all():
        print "Test 2 looks good!"
    else:
        print "Uh oh, I think there is a problem!"

if __name__ == "__main__":
    tests()




