import cherrypy
class WelcomePage:
    def greetUser(self, name = None):
        if name:
# Greet the user!
            return "Hey %s, what's up?" % name
            return"<fontcolor='%s'> Hey %s, What's up?</font>" % name
        else:
	    if name is None:
		    return 'Please enter your name < a href="./"here</a>.'
            #return 'call me like <i>http://localhost:8080/greetUser?name=Josh</i>'
            else
	    return 'No, really,enter yourname <a href="./">here</a>.'
User.exposed = True

    greetUser.exposed = True
cherrypy.quickstart(WelcomePage())

