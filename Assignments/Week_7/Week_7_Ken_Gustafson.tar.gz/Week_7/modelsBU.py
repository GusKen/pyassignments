# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#     * Rearrange models' order
#     * Make sure each model has one field with primary_key=True
# Feel free to rename the models, but don't rename db_table values or field names.
#
# Also note: You'll have to insert the output of 'django-admin.py sqlcustom [appname]'
# into your database.

from django.db import models

class AuthGroup(models.Model):
    id = models.IntegerField(primary_key=True)
    name = models.CharField(unique=True, max_length=80)
    class Meta:
        db_table = u'auth_group'

class AuthGroupPermissions(models.Model):
    id = models.IntegerField(primary_key=True)
    group_id = models.IntegerField()
    permission = models.ForeignKey(AuthPermission)
    class Meta:
        db_table = u'auth_group_permissions'

class AuthMessage(models.Model):
    id = models.IntegerField(primary_key=True)
    user = models.ForeignKey(AuthUser)
    message = models.TextField()
    class Meta:
        db_table = u'auth_message'

class AuthPermission(models.Model):
    id = models.IntegerField(primary_key=True)
    name = models.CharField(max_length=50)
    content_type_id = models.IntegerField()
    codename = models.CharField(max_length=100)
    class Meta:
        db_table = u'auth_permission'

class AuthUser(models.Model):
    id = models.IntegerField(primary_key=True)
    username = models.CharField(unique=True, max_length=30)
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    email = models.CharField(max_length=75)
    password = models.CharField(max_length=128)
    is_staff = models.BooleanField()
    is_active = models.BooleanField()
    is_superuser = models.BooleanField()
    last_login = models.DateTimeField()
    date_joined = models.DateTimeField()
    class Meta:
        db_table = u'auth_user'

class AuthUserGroups(models.Model):
    id = models.IntegerField(primary_key=True)
    user_id = models.IntegerField()
    group = models.ForeignKey(AuthGroup)
    class Meta:
        db_table = u'auth_user_groups'

class AuthUserUserPermissions(models.Model):
    id = models.IntegerField(primary_key=True)
    user_id = models.IntegerField()
    permission = models.ForeignKey(AuthPermission)
    class Meta:
        db_table = u'auth_user_user_permissions'

class DjangoContentType(models.Model):
    id = models.IntegerField(primary_key=True)
    name = models.CharField(max_length=100)
    app_label = models.CharField(max_length=100)
    model = models.CharField(max_length=100)
    class Meta:
        db_table = u'django_content_type'

class DjangoSession(models.Model):
    session_key = models.CharField(max_length=40, primary_key=True)
    session_data = models.TextField()
    expire_date = models.DateTimeField()
    class Meta:
        db_table = u'django_session'

class DjangoSite(models.Model):
    id = models.IntegerField(primary_key=True)
    domain = models.CharField(max_length=100)
    name = models.CharField(max_length=50)
    class Meta:
        db_table = u'django_site'

class Spmref1(models.Model):
    title = models.TextField(db_column=u'Title', blank=True) # Field name made lowercase. This field type is a guess.
    entry_type = models.TextField(db_column=u'Entry Type', blank=True) # Field renamed to remove spaces. Field name made lowercase. This field type is a guess.
    author = models.TextField(db_column=u'Author', blank=True) # Field name made lowercase. This field type is a guess.
    bibtex_key = models.TextField(db_column=u'Bibtex Key', blank=True) # Field renamed to remove spaces. Field name made lowercase. This field type is a guess.
    book_title = models.TextField(db_column=u'Book Title', blank=True) # Field renamed to remove spaces. Field name made lowercase. This field type is a guess.
    editor = models.TextField(db_column=u'Editor', blank=True) # Field name made lowercase. This field type is a guess.
    organization = models.TextField(db_column=u'Organization', blank=True) # Field name made lowercase. This field type is a guess.
    publisher = models.TextField(db_column=u'Publisher', blank=True) # Field name made lowercase. This field type is a guess.
    address = models.TextField(db_column=u'Address', blank=True) # Field name made lowercase. This field type is a guess.
    edition = models.TextField(db_column=u'Edition', blank=True) # Field name made lowercase. This field type is a guess.
    pages = models.TextField(db_column=u'Pages', blank=True) # Field name made lowercase. This field type is a guess.
    year = models.TextField(db_column=u'Year', blank=True) # Field name made lowercase. This field type is a guess.
    isbn# = models.TextField(db_column=u'ISBN#', blank=True) # Field name made lowercase. This field type is a guess.
    journal = models.TextField(db_column=u'Journal', blank=True) # Field name made lowercase. This field type is a guess.
    doi = models.TextField(db_column=u'DOI', blank=True) # Field name made lowercase. This field type is a guess.
    month = models.TextField(db_column=u'Month', blank=True) # Field name made lowercase. This field type is a guess.
    number = models.TextField(db_column=u'Number', blank=True) # Field name made lowercase. This field type is a guess.
    how_published = models.TextField(db_column=u'How Published', blank=True) # Field renamed to remove spaces. Field name made lowercase. This field type is a guess.
    chapter = models.TextField(db_column=u'Chapter', blank=True) # Field name made lowercase. This field type is a guess.
    series = models.TextField(db_column=u'Series', blank=True) # Field name made lowercase. This field type is a guess.
    volume = models.TextField(db_column=u'Volume', blank=True) # Field name made lowercase. This field type is a guess.
    cross_reference = models.TextField(db_column=u'Cross-Reference', blank=True) # Field renamed to remove dashes. Field name made lowercase. This field type is a guess.
    keywords = models.TextField(db_column=u'Keywords', blank=True) # Field name made lowercase. This field type is a guess.
    url = models.TextField(db_column=u'URL', blank=True) # Field name made lowercase. This field type is a guess.
    abstract = models.TextField(db_column=u'Abstract', blank=True) # Field name made lowercase. This field type is a guess.
    notes = models.TextField(db_column=u'Notes', blank=True) # Field name made lowercase. This field type is a guess.
    class Meta:
        db_table = u'spmref1'

