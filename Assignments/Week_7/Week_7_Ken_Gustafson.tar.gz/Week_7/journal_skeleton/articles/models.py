from datetime import datetime

from django.db import models
from django.contrib.auth.models import User

class Article(models.Model):
    # give me appropriate attributes
    
    class Meta:
        verbose_name = _("Article")
        verbose_name_plural = _("Articles")
    
    def __unicode__(self):
        return self.title
    
    def get_absolute_url(self):
        return reverse("article_detail", kwargs={"slug": self.slug})
