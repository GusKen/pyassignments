from django.contrib import admin
from mysite.myapp.models import Spmref2

admin.site.register(Spmref2)
#admin.site.register(Author)
#admin.site.register(Book)
#admin.site.register(Spmref2)
