# Create your views here.
from django.http import HttpResponse
from django.shortcuts import render_to_response
from mysite.myapp.models import Spmref2
def search_form(request):
    return render_to_response('search_form.html')

def search(request):
    if 'q' in request.GET and request.GET['q']:
        q = request.GET['q']
        Publications = Spmref2.objects.filter(author__icontains=q)
        return render_to_response('search_results.html',
            {'Publications': Publications , 'query': q})
    else:
        return HttpResponse('Please submit a search term.')

