README   Ken Gustafson Oct 26 2010
1) Diango site is directory mysite

2) Used a .bib file spmref.bib as a legacy bib file. It contains
78 or 79 references in the area of nonlinear optics.

3) Used tellico to obtain spmref2.csv and then sqlite3 to 
generate SPM_Ref3.db the data base used in Django

4) The scanned views.pdf ( poor quality) shows:
    page 1 -The admin site
    page 2 - The search-form form 
    page 3 - The query response to Townes
    page 4 - shows the tellico listing (page 1 ) of the .bib files ( author
and title only)
    page 5 - shows the listing I get when I click on the Spmref2s in Myapp of 
the admin site ( python manage.py runserver)

5) References can be added to the Spmref2 data base.

6) Never got to uploading a .bib file but want to pursue it.

7) Porting to an apache server maybe is useful?

8) Quite different from using "Kompozer" which is a WYSIWYG GUI I have used!
