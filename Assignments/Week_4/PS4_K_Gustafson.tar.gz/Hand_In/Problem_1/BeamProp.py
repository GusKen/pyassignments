# Author : Alexander Baker

import sys
from pylab import figure, show, clf, savefig, cm
from numpy.fft import fft, fft2, ifft, ifft2, fftshift
from optparse import OptionParser
from numpy import *
from pylab import *
import scipy.linalg
from scipy.integrate import *
import matplotlib.pylab as plt

from scipy.special import *

def generateResolution(n):
   return 2**n, (2**n)-1

def store_value(option, opt_str, value, parser):
    setattr(parser.values, option.dest, value)
   
def main():

   parser = OptionParser()

   parser.add_option("-r", "--resolution", action="callback", callback=store_value, type="int", nargs=1, dest="resolution", help="resolution of the grid parameter")   
   parser.add_option("-g", "--grid", action="callback", callback=store_value, type="int", nargs=1, dest="grid", help="grid size parameter")   
   parser.add_option("-s", "--steps", action="callback", callback=store_value, type="int", nargs=1, dest="steps", help="number of steps")
   parser.add_option("-b", "--beam", action="callback", callback=store_value, type="int", nargs=1, dest="beam", help="beam size")
   parser.add_option("-c", "--core", action="callback", callback=store_value, type="float", nargs=1, dest="core", help="beam size")
   parser.add_option("-p", "--phase", action="callback", callback=store_value, type="int", nargs=1, dest="phase", help="phase size parameter")   
   parser.add_option("-i", "--image", action="callback", callback=store_value, type="string", nargs=1, dest="image", help="phase size parameter")   

   (options, args) = parser.parse_args()
   
   grid_resolution = 6        
   grid_size = 8
   steps = 3
   lam = 1.0*10**(-6)
   BR=100*(10**(-6))
   N_sol=sqrt(10)
   print lam, N_sol
   pkinitnlph=0.0005
   NRL=226
   NRH=1024
   z=0.00776
   fl=50000
   beam = 8
   core = 0.3
   phase = 0
#  image = 'bw'
   image = 'co'  
   if options.resolution:
      grid_resolution = options.resolution   
      
   if options.grid:
      grid_size = options.grid       

   if options.steps:
      steps = options.steps

   if options.beam:
      beam = options.beam

   if options.core:
      core = options.core
      
   if options.phase:
      phase = options.phase

   if options.image:
      image = options.image

   print '\n######################################################'
   print '# Numerical Lattice Model'
   print '# Alexander Baker - August 2007'
   print '######################################################\n'

   grid_resolution, grid_resolution_1 = generateResolution(grid_resolution)
   
   # The grid size effects the number of steps we apply to get to the upper limit

   print "grid_size : [%d]\ngrid_resolution [%d]\ngrid_resolution-1 [%d]" %(grid_size, grid_resolution, grid_resolution_1)

   x1 = arange(-1 * 1.0* grid_size,(-1 * grid_size) + grid_resolution_1 * 1.0 * (2 * grid_size)/grid_resolution, (grid_size * 1.0)/grid_resolution)

   x2 = arange(-1 * 1.0 * grid_size,(-1 * grid_size) + grid_resolution_1 * 1.0 * (2 * grid_size)/grid_resolution, (grid_size * 1.0)/grid_resolution)

   xmin, xmax, ymin, ymax = -1 * 1.0 * grid_size, (-1 * grid_size) + grid_resolution_1 * 1.0 * (2 * grid_size)/grid_resolution, -1 * 1.0 * grid_size, (-1 * grid_size) + grid_resolution_1 * 1.0 * (2 * grid_size)/grid_resolution
   extent = xmin, xmax, ymin, ymax

   print "\ngrid extent X-[%f][%f] Y-[%f][%f]" % (xmin, xmax, ymin, ymax)
   print "shape x1", shape(x1)
   print "shape x2", shape(x2)
   print "step [%f]" % ((grid_size * 1.0)/grid_resolution)
   print "start [%f], end[%f]" % (-1 * 1.0* grid_size, grid_resolution_1 * 1.0 * (2 * grid_size)/grid_resolution)

   [x1,x2] = meshgrid(x1,x2)

   rbeam = beam
   
   wcore = core
   vpos = 1
   _del = 1
   n2I=((lam*N_sol/(pi*BR))**2)/2.
   dz=pkinitnlph*lam/(2*pi*n2I)
   print dz
   NZ=round(z/dz)
   print NZ
   z_dif = (pi*(BR)**2)/(lam)
   z_nl=lam/(2*pi*n2I)
   z_sf = sqrt(z_dif*z_nl/2)
   z_col= sqrt((2.*z_dif*z_nl)/(1-2.*z_nl/z_dif))
   N_sol_ck = sqrt(z_dif/(z_nl))

   d=arange(0,NZ,1)
   print d
   d=d*dz+dz
   ##d=arange(dz,4*dz,dz)
   print d
   
   ca= jn_zeros(0,NRL)
   
   #print c
   d1= arange(NRL,NRH+1,1)
   cb= 1/(8.*(.75+ (d1+0.))*pi)
   cb=(.75 + d1)*pi
   
   #print cb		   
   c=append(ca,cb) 
   print c
   print c[NRL+774]
   print c[1000]
   print c[NRH]
   print c[226]
   print c[225]
   print c[0]
   print transpose(c)
   print ca[225]
   prod=dot((c.T),c)
   print prod
   R=c[NRH]*lam/(2*pi)
   V=c[NRH]/(2*pi*R)
   r=transpose(c)*R/c[NRH]
   v=c/(2*pi*R)
   [Jn,Jm]= meshgrid(c,c)
   #d=(c.transpose())*c
   od=outer(c.transpose(),c)
   oe=outer(abs(j1(c).transpose()),abs(j1(c)))
   print od[0,0]
   #print jn(ord,1)
   
   T=(2/c[NRH])*(j0(od/c[NRH])/oe)
   m1= ( abs(j1(transpose(c)))/R)

   pnum = v*v
   #pdenom = sqrt((lam*lam)**(-1)-v*v )+1/lam
   lin_phase=-1j*2*pi*dz*pnum*lam/2.
   lin_prop=exp(lin_phase)
   lens = exp(-1j*(2*pi/lam)*r*r/(2*fl))

   f_in = exp(-(r*r)/(BR*BR))
   f_in=f_in*lens
   F_in=f_in/m1
   F_loop=F_in
   F_T=dot(T,F_loop)
   f_T_loop=F_T*m1
   print f_T_loop
   print f_T_loop[0]
   print f_T_loop[1000]
   print "finished"
   AxPsO = ((abs(f_T_loop[0])*v[1])**2- (abs(f_T_loop[1])*v[0])**2)/((v[1]**2) -v[0]**2)
   wv2= (v**3)*(abs(f_T_loop)**2)
   V2avO=trapz(v,wv2)+(AxPsO+(abs(f_T_loop[1])**2))*(v[0]**4)/12.
   #Propagation Loop
   AxIn = zeros(NZ,float)
   Pow=zeros(NZ,float)
   R2av=zeros(NZ,float)
   AxPs=zeros(NZ,float)
   V2av=zeros(NZ,float)
   bsa=zeros(NZ,float)
   for j in arange(0,NZ,1):
	   f_loop=F_loop*m1
	   #print  f_loop[0]
	   AxIn[j]=((abs(f_loop[0])*r[1])**2 - (abs(f_loop[1])*r[0])**2)/((r[1])**2-(r[0])**2)
           Ints=r*(abs(f_loop)**2)
	   Pow[j]=( trapz(r,Ints)+Ints[0]*r[0]/2.)
	   wr2=(r**2)*Ints
	   R2av[j]=trapz(r,wr2)/Pow[j]+Ints[0]*(r[0]**3)/2.
	   nl_prop = exp(1j*pkinitnlph*abs(f_loop)**2)
	   F_loop=F_loop*nl_prop
	   F_T=dot(T,F_loop)
	   f_T_loop=F_T*m1
	   #print f_T_loop
	   #print f_T_loop[0]
	   bsa=(abs(f_T_loop[0]))*v[1]
	   #print bsa
	   #print f_T_loop[0]
	   bsb=(abs(f_T_loop[1]))*v[0]
	   #print bsb
	   bsc=(v[1]*v[1] - v[0]*v[0])
	   #print bsc
	   AuPs=(bsa*bsa - bsb*bsb)/bsc
	   AxPs[j]=AuPs
           wv2=(v**3)*(abs(f_T_loop)**2)
	   Int=trapz(v,wv2)
	   V2av[j]=Int+ (AxPs[j]+(abs(f_T_loop[1])*abs(f_T_loop[1])))*(v[0]**4)/12
	   F_T=F_T*lin_prop
	   F_loop=dot(T,F_T)
   dmm=d*1000
   print d
   print dmm
   zmm=z*1000
   print sqrt(AxIn)
   print "\nRayleigh Range = [%f] mm" % (z_dif*1000)
   print "\nNonlinear Length = [%f] mm" % (z_nl*1000)
   print "\nSelf-focussing Distance = [%f] mm" % (z_sf*1000)
   print "\nSoliton Number = [%f] mm" % (N_sol)
   print "\nInitial Beam 1/e amplitude HW = [%f] um" % (BR*10**6)
   print "\nWavelength = [%f] um" % (lam*10**6)
   print "\nNumber of Radial Points= [%i] " % (NRH)
   print "\nNumber of Axial Steps = [%i] " % (NZ)

   print "\nrbeam [%d]\nwcore [%f]\nvpos [%f]\n_del [%f]" % (rbeam, wcore, vpos, _del)
   fig=plt.figure()
   ax1=fig.add_subplot(111)
   p1= ax1.plot(dmm,sqrt(AxIn))
   ax1.set_xlim(xmin=0, xmax= 8)
   ax1.set_ylim(ymin=0, ymax=30)
   plt.xlabel("Axial Distance in mm")
   plt.ylabel("Amplitude on Axis in units of Initial Amplitude")
   #plot (sqrt(AxIn))
   show()
   #plot (dmm)
   #show()
   #
   # Step 1. Take your initial beam profile (gaussian, a vortex etc etc) at z = 0
   #
   
   y = 1.0*exp(-2*(x1**2 + x2**2)/rbeam**2)*exp(1j* phase *(+arctan2(x2,x1))) * tanh(pow((x1**2 + x2**2), 0.5)/wcore)           

   fig1 = figure(1)
   fig1.clf()
   ax1a = fig1.add_subplot(121)

   if image == 'bw':
	   ax1a.imshow(angle((y)), cmap=cm.gist_gray, alpha=.9, interpolation='bilinear', extent=extent)
   else:
	   ax1a.imshow(angle((y)), cmap=cm.jet, alpha=.9, interpolation='bilinear', extent=extent)
   ax1a.set_title(r'Angle')
   ax1b = fig1.add_subplot(122)

   if image == 'bw':
       ax1b.imshow(abs((y)), cmap=cm.gist_gray, alpha=.9, interpolation='bilinear', extent=extent)
   else:
       ax1b.imshow(abs((y)), cmap=cm.jet, alpha=.9, interpolation='bilinear', extent=extent)

   ax1b.set_title(r'Amplitude')
   savefig('big_start_' + str(wcore)+'_' + str(vpos) +'.png')  

   u1 = arange(-1.0,-1+1.0*grid_resolution_1* ((2 * 1.0)/grid_resolution), 1.0/grid_resolution)
   u2 = arange(-1.0,-1+1.0*grid_resolution_1* ((2 * 1.0)/grid_resolution), 1.0/grid_resolution)

   u1min, u1max, u2min, u2max = -1.0, -1+1.0*grid_resolution_1* ((2 * 1.0)/grid_resolution), -1.0, -1+1.0*grid_resolution_1* ((2 * 1.0)/grid_resolution)

   print "\npropagation grid X-[%f][%f] Y-[%f][%f]" % (u1min, u1max, u2min, u2max)

   print "shape u1", shape(u1)
   print "shape u2", shape(u2)
   
   print "step [%f]" % (1.0/grid_resolution)
   print "start [%f], end[%f]" % (-1.0, -1+1.0*grid_resolution_1* ((2 * 1.0)/grid_resolution))

   print "\nbeam power (start) - [%f]" % (sum(sum(abs(y**2))))

   [u1,u2] = meshgrid(u1,u2)

   t = exp(2*pi*1j*(u1**2 + u2**2)*_del)
   w = fftshift(t)

   #
   # Step 2. Split step progagation
   #

   for i in arange(100,100+steps, 1):
     z = fft2(y)
     zp = z * w   
     yp = ifft2(zp)
     p = (exp(+0.01*pi*1j*(x1**2 + x2**2)*_del + 0.05*pi*1j*y*conj(y))*_del); 
     yp = yp * p
     y = yp
     zp = fft2(yp)
     zp = zp * w
     yp = ifft2(zp)

     fig3 = figure(3)
     fig3.clf()
     ax3 = fig3.add_subplot(111)

     if image == 'bw':   
        ax3.imshow(abs((yp)), cmap=cm.gist_gray, alpha=.9, interpolation='bilinear', extent=extent)
     else:
        ax3.imshow(abs((yp)), cmap=cm.jet, alpha=.9, interpolation='bilinear', extent=extent)
     savefig('Gaussian' + str(wcore)+'_' + str(i) +'.png')  

     ax3 = fig3.add_subplot(111)
     if image == 'bw':   
        ax3.imshow(angle((yp)), cmap=cm.gist_gray, alpha=.9, interpolation='bilinear', extent=extent)
     else :
        ax3.imshow(angle((yp)), cmap=cm.jet, alpha=.9, interpolation='bilinear', extent=extent)    

     print sum(sum(abs(yp**2))), i-100
   print "beam power (end) - [%f]" % (sum(sum(abs(yp**2))))

   fig2 = figure(2)
   fig2.clf()
   ax2a = fig2.add_subplot(121)
   if image == 'bw':   
      ax2a.imshow(angle((yp)), cmap=cm.gist_gray, alpha=.9, interpolation='bilinear', extent=extent)
   else:
      ax2a.imshow(angle((yp)), cmap=cm.jet, alpha=.9, interpolation='bilinear', extent=extent)
   ax2a.set_title(r'Angle')
   ax2b = fig2.add_subplot(122)
   if image == 'bw':   
      ax2b.imshow(abs((yp)), cmap=cm.gist_gray, alpha=.9, interpolation='bilinear', extent=extent)
   else:
      ax2b.imshow(abs((yp)), cmap=cm.jet, alpha=.9, interpolation='bilinear', extent=extent)
   ax2b.set_title(r'Amplitude')
# savefig('big_end_' + str(wcore)+'_' + str(vpos) +'.png')

   print '\ndone. ok'

if __name__ == "__main__":   
   main()      
#show()

