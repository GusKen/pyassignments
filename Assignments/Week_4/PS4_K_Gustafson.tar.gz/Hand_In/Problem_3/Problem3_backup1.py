import numpy as np
import math
from numpy import arange
#import pylab as plt
import pylab as py
import scipy
from pylab import axis,subplot, show
import string
import matplotlib.pyplot as plt
#from matplotlib import *
import matplotlib
from matplotlib.pyplot import gca
from matplotlib.widgets import RectangleSelector
from matplotlib.blocking_input import BlockingInput
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
#import xlrd
import matplotlib.mlab as mlab
import Image
from cStringIO import StringIO
from matplotlib.figure import Figure
import Tkinter
#s=StringIO("""#hormel.csv""")
r=mlab.csv2rec('hormel.csv')
print r
#DataIn = np.loadtxt('hormel.csv', dtype={'names': ('Date',
#	'Open','High','Low','Close','Volume'),'formats':('s10','f10','f10','f10','f10','f10')})
#filehandle=open("hormel.csv","r")
#fig=Figure(figsize=(8,8))
#canvas = FigureCanvas(fig)
#ax1=fig.add_subplot(221)
#ax1=plt.add_subplot(221)
#columnes= r.split("\t")

# Blocking Class to see how the class structure works
class BlockingRectangleSelector:
    """
    Blocking rectangle selector selects once then continues with script.
    """
    def __init__(self, ax=None):
        if ax is None: ax=gca()
        self.ax = ax

        # drawtype is 'box' or 'line' or 'none'
        self.selector = RectangleSelector(self.ax, self._callback,
                               drawtype='box',useblit=True,
                               minspanx=5,minspany=5,spancoords='pixels')
        self.selector.set_active(False)
        self.block = BlockingInput(self.ax.figure)

    def _callback(self, event1, event2):
        """
        Selection callback.  event1 and event2 are the press and release events
        """
        x1, y1 = event1.xdata, event1.ydata
        x2, y2 = event2.xdata, event2.ydata
        if x1>x2: x1,x2 = x2,x1
        if y1>y2: y1,y2 = y2,y1
        self.x1,self.x2,self.y1,self.y2 = x1,x2,y1,y2
        self.ax.figure.canvas.stop_event_loop()

    def select(self):
        """
        Wait for box to be selected on the axes.
        """

        # Make sure the graph is drawn before select.
        # This appears to be needed for ipython.
        self.ax.figure.canvas.draw_idle()

        # Wait for selector to complete
        self.selector.set_active(True)
        self.block()
        self.selector.set_active(False)

        # Force redraw, otherwise next show() doesn't
        # update the graph.
        #self.ax.figure.canvas.draw_idle()

    def remove(self):
        """
        Remove the selector from the axes.

        Note: this currently does nothing since matplotlib doesn't allow
        widgets to be removed from axes.
        """
        pass  # rectangle widget can't be removed from axes
# End Class 
def ginput_rect(ax=None):
    """
    Wait for user to select a region on the axes.
    
    Returns x1,x2,y1,y2
    """
    s = BlockingRectangleSelector(ax=ax)
    s.select()
    s.remove()
    return s.x1,s.x2,s.y1,s.y2

class AnnoteFinder:
    def __init__(self, xdata, ydata, annotes, axis=None, xtol=None, ytol=None):
       self.data = zip(xdata, ydata, annotes)
       if xtol is None:
           xtol = ((max(xdata) - min(xdata))/float(len(xdata)))/2
       if ytol is None:
           ytol = ((max(ydata) - min(ydata))/float(len(ydata)))/2
       self.xtol = xtol
       self.ytol = ytol
       if axis is None:
          #self.axis = pylab.gca()
          self.axis = py.gca()
       else:
           self.axis= axis
       self.drawnAnnotations = {}
       self.links = []
   
    def distance(self, x1, x2, y1, y2):
       """
     return the distance between two points
  37     """
       return math.hypot(x1 - x2, y1 - y2)
  
    def __call__(self, event):
       if event.inaxes:
          clickX = event.xdata
          clickY = event.ydata
          if self.axis is None or self.axis==event.inaxes:
             annotes = []
             for x,y,a in self.data:
                 if  clickX-self.xtol < x < clickX+self.xtol and  clickY-self.ytol < y < clickY+self.ytol :
                     annotes.append((self.distance(x,clickX,y,clickY),x,y, a) )
             if annotes:
               annotes.sort()
               distance, x, y, annote = annotes[0]
               self.drawAnnote(event.inaxes, x, y, annote)
               for l in self.links:
                   l.drawSpecificAnnote(annote)
   
    def drawAnnote(self, axis, x, y, annote):
       if (x,y) in self.drawnAnnotations:
         markers = self.drawnAnnotations[(x,y)]
         for m in markers:
            m.set_visible(not m.get_visible())
         self.axis.figure.canvas.draw()
       else:
         t = axis.text(x,y, "(%3.2f, %3.2f) - %s"%(x,y,annote), )
         m = axis.scatter([x],[y], marker='d', c='r', zorder=100)
         self.drawnAnnotations[(x,y)] =(t,m)
         self.axis.figure.canvas.draw()
  
    def drawSpecificAnnote(self, annote):
      annotesToDraw = [(x,y,a) for x,y,a in self.data if a==annote]
      for x,y,a in annotesToDraw:
         self.drawAnnote(self.axis, x, y, a)

class RedoSubplotColors:
    def get_data_points():
	return
    def if_then_change_sub_plot_data_color():
	return
# This is the demo routine
#End of function
col_0=zip(*r)[0]
col_1=zip(*r)[1]
col_2=zip(*r)[2]
col_3=zip(*r)[3]
col_4=zip(*r)[4]
print col_4
fig=plt.figure()
#fig=Figure(figsize=(8,8))
#canvas = FigureCanvas(fig)
ax1=fig.add_subplot(221)
#b=ax1.scatter(col_1,col_2,s=3,color='r');
plt.scatter(col_1,col_2,s=3,color='r')
plt.savefig("col_1 versus col_2")
#canvas.printfigure("col_1 versus col_2")
#im1=ax1.imshow(plot_o)
ax2=fig.add_subplot(222)
plt.scatter(col_2,col_3,s=3,color='r')
ax3=fig.add_subplot(223)
plt.scatter(col_4,col_3,s=3,color='r')
#x1,x2,y1,y2 = ginput_rect()
ax4=fig.add_subplot(224)
plt.scatter(col_4,col_1,s=3,color='r')
print "\n      click  -->  release"
#The big test

x1,x2,y1,y2 = ginput_rect()

def linkAnnotationFinders(afs):
   for i in range(len(afs)):
      allButSelfAfs = afs[:i]+afs[i+1:]
      afs[i].links.extend(allButSelfAfs)

subplot(221)
#x=col_1
#y=col_2
x=col_1
y=col_2
plt.scatter(x,y)
annotes=['a','b','c','d','e','f']
af1 = AnnoteFinder(x,y, annotes)
py.connect('button_press_event', af1)

x=col_2
y=col_3
subplot(222)
plt.scatter(x,y)
af2 = AnnoteFinder(x,y, annotes)
py.connect('button_press_event', af2)
x=col_3
y=col_4
subplot(223)
plt.scatter(x,y)
af3 = AnnoteFinder(x,y, annotes)
py.connect('button_press_event', af3)
x=col_4
y=col_1
subplot(224)
plt.scatter(x,y)
af4 = AnnoteFinder(x,y, annotes)
py.connect('button_press_event', af3)

linkAnnotationFinders([af1, af2,af3,af4])

print "(%3.2f, %3.2f) --> (%3.2f, %3.2f)"%(x1,y1,x2,y2)

    # Zoom in to the selected rectangle
#py.axis([x1, x2, y1, y2])
#end big test
plt.show()

