		T. Ken Gustafson (auditor)
a) Relevant File is Prob_Set6.py

b) set a default image  http://www.python.org/images/success/nasa.jpg

c) picture can be changed by typing in a new http image file in the input box
 
d) Did not have time to do any picture processing. Played with the search.py
file some. 

e) Particular problems - "global " versus "local" variables and how to 
properly define them, and 'Nonetype object' has no attribute.
 
