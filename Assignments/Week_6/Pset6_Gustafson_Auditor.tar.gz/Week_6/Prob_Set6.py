
import urllib
from enthought.traits.api import *
from string import *
import matplotlib.pyplot as mimage
import enthought.traits.ui
from enthought.traits.ui.api import *
from enthought.traits.api import Any, Instance, HasTraits, Trait, String
from enthought.traits.ui.wx.editor import Editor
from enthought.traits.ui.basic_editor_factory import BasicEditorFactory
from enthought.traits.ui.api import View, Item, ButtonEditor
import wx
import matplotlib
matplotlib.use('WXAgg')
from matplotlib.backends.backend_wxagg import FigureCanvasWxAgg as FigureCanvas
from matplotlib.figure import Figure
from matplotlib.backends.backend_wx import NavigationToolbar2Wx
from enthought.traits.api import *
from enthought.traits.ui.api import View, Item, Group, HSplit, Handler, ButtonEditor
from enthought.traits.ui.menu import NoButtons
from matplotlib.figure import Figure
import StringIO

def Search(URLR, Pic):
    image = urllib.URLopener()
    return image.retrieve(URLR, Pic)
class TextDisplay(HasTraits):
    string =  String()
    view = View( Item('string', show_label=False, springy=True, style='custom' ))

class _MPLFigureEditor(Editor):
    scrollable = True

    def init(self,parent):
        self.control = self._create_canvas(parent)
        self.set_tooltip()
    def update_editor(self):
        pass
    def _create_canvas(self,parent) :
        panel = wx.Panel(parent, -1, style=wx.CLIP_CHILDREN)
        sizer = wx.BoxSizer(wx.VERTICAL)
        panel.SetSizer(sizer)
        # matplotlib commands to create a canvas
        mpl_control = FigureCanvas(panel, -1, self.value)
        sizer.Add(mpl_control, 1, wx.LEFT | wx.TOP | wx.GROW)
        toolbar = NavigationToolbar2Wx(mpl_control)
        sizer.Add(toolbar, 0, wx.EXPAND)
        self.value.canvas.SetMinSize((3,3))
        return panel

class MPLFigureEditor(BasicEditorFactory):
    klass = _MPLFigureEditor

global input
global URLG_Default
global URLG
URLG=String()
URLG_Default=String()
URLG_Default= 'http://www.python.org/images/success/nasa.jpg'
class Test(HasTraits):
    display= Instance(TextDisplay,())
    figure = Instance(Figure, ())
    input=String()
    output=String()
    URLG=String()
    URLG_Default=String()
    def _input_changed(self):
	input=self.input
        self.output = self.input
	output=self.output
	URLG=input
	print 'output', output, self.output, URLG
	global output
	return URLG, output
   
    view = View('input',Item('output'),Group(Item('rez',width=20,height=7
	              ,resizable=True,padding=1,
                      label="Result",enabled_when="True",
		         full_size=False,dock='horizontal'),
			 Item('rez',width=20,height=7,resizable=True,padding=1,
                      label="Input_URL",enabled_when="True",
		         full_size=False,dock='horizontal'),
		Item('figure', editor=MPLFigureEditor(),height=400,
                                show_label= True),
			    ),
                buttons= [OKButton, "two","three",
			"four","five","six"],
		
		title = 'Search, Download, and Process Fig', resizable=True,
		scrollable=False, 
		)
    print 'input', URLG
    def __init__(self):
        super(Test, self).__init__()
        axes = self.figure.add_subplot(111)
	print 'This is a test', URLG
	Search(URLG_Default,"NASA.jpg")
	im=mimage.imread("NASA.jpg")
	axes.imshow(im)
        Search( URLG_Default ,"NASA.jpg")
        im=mimage.imread("NASA.jpg")
        axes.imshow(im)
	
def image_show(self, image):
    wx.CallAfter(self.figure.canvas.draw)

    display = Instance(TextDisplay, ())

print ('final URLG'), URLG
Test().configure_traits() 
if URLG == URLG_Default:
    URLG=URLG_Default
else:
    URLG_Default=output
    Test().configure_traits() 

