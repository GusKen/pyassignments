
import urllib
from enthought.traits.api import *
from string import *
import math
import pylab as py
import matplotlib.pyplot as mimage
import enthought.traits.ui
from enthought.traits.ui.api import *
from enthought.traits.api import Any, Instance, HasTraits, Trait, String
from enthought.traits.ui.wx.editor import Editor
from enthought.traits.ui.basic_editor_factory import BasicEditorFactory
from enthought.traits.ui.api import View, Item, ButtonEditor
import wx
import matplotlib
matplotlib.use('WXAgg')
from matplotlib.backends.backend_wxagg import FigureCanvasWxAgg as FigureCanvas
from matplotlib.figure import Figure
from matplotlib.backends.backend_wx import NavigationToolbar2Wx
from threading import Thread
from time import sleep
from enthought.traits.api import *
from enthought.traits.ui.api import View, Item, Group, HSplit, Handler, ButtonEditor
from enthought.traits.ui.menu import NoButtons
from matplotlib.figure import Figure
from scipy import * 
import wx
from scipy import *
import StringIO

def Search(URLR, Pic):
    image = urllib.URLopener()
    return image.retrieve(URLR, Pic)
class TextDisplay(HasTraits):
    string =  String()
    view = View( Item('string', show_label=False, springy=True, style='custom' ))

class _MPLFigureEditor(Editor):
    scrollable = True

    def init(self,parent):
        self.control = self._create_canvas(parent)
        self.set_tooltip()
    def update_editor(self):
        pass
    def _create_canvas(self,parent) :
        panel = wx.Panel(parent, -1, style=wx.CLIP_CHILDREN)
        sizer = wx.BoxSizer(wx.VERTICAL)
        panel.SetSizer(sizer)
        # matplotlib commands to create a canvas
        mpl_control = FigureCanvas(panel, -1, self.value)
        sizer.Add(mpl_control, 1, wx.LEFT | wx.TOP | wx.GROW)
        toolbar = NavigationToolbar2Wx(mpl_control)
        sizer.Add(toolbar, 0, wx.EXPAND)
        self.value.canvas.SetMinSize((3,3))
        return panel

class MPLFigureEditor(BasicEditorFactory):
    klass = _MPLFigureEditor

#class EchoBox(HasTraits):
#    input =  Str()
#   output = Str()
#    def _input_changed(self):
#        self.output = self.input
URLG=String()
URLG= "success/nasa.jpg"
class Test(HasTraits):
    display= Instance(TextDisplay,())
    figure = Instance(Figure, ())
    input=String()
    output=String()
    URLG=String()
    def _input_changed(self):
        input= self.input='success/nasa.jpg'
        self.output = self.input
	global URLG
	URLG=input
	print 'output', self.output, URLG
	return URLG
    view = View('input',Item('output'),Group(Item('rez',width=20,height=7
	              ,resizable=True,padding=1,
                      label="Result",enabled_when="True",
		         full_size=False,dock='horizontal'),
			 Item('rez',width=20,height=7,resizable=True,padding=1,
                      label="Input_URL",enabled_when="True",
		         full_size=False,dock='horizontal'),
		Item('figure', editor=MPLFigureEditor(),height=400,
                                show_label= True),
			    ),
                buttons= ["add_one","add_two","three","four","five","six"],
		title = 'Search, Download, and Process Fig', resizable=True,
		scrollable=False, 
		)
    print 'input', URLG
    def __init__(self):
        super(Test, self).__init__()
        axes = self.figure.add_subplot(111)
	#URLF="Input_URL"
	print URLG
	Search("http://www.python.org/images/success/nasa.jpg","NASA.jpg")
	#Search("http://www.python.org/images/'URLG'","NASA.jpg")
	#Search("URLF.jpg","NASA.jpg")
	#Search("URLF","NASA.jpg")
	im=mimage.imread("NASA.jpg")
	axes.imshow(im)

def image_show(self, image):
    self.figure.axes[0].images=[]
    self.figure.axes[0].imshow(image, aspect='auto')
    wx.CallAfter(self.figure.canvas.draw)

class MainWindow(HasTraits):
    image = urllib.URLopener()
    image.retrieve("http://www.python.org/images/success/nasa.jpg",
		"NASA.jpg")
    #image.retrieve("http://www.python.org/images/URLG",
		#"NASA.jpg")
    display = Instance(TextDisplay, ())

Test().configure_traits() 

#print Test._input_changed.self.output
print  URLG
