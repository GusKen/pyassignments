# http://m-eken.com
# python 3
#google Searcher
import Tkinter
import urllib
import urllib2
from Tkinter import *

class window:
    def __init__(self,root):
        self.root=root
        self.root.title("Google Searcher")
        Text(self.root, width=50,height=25).pack()
        self.init_widgets()

    def init_widgets(self):
        Tkinter.Button(self.root, command=self.insert_text,text="Good",width="10").place(x=400,y=10)
        self.txt=Text(self.root,width="52",height="10", font=12)
        self.txt.place(x=10,y=40)
        self.searchWord=Text(self.root,width="42",height="1", font=12)
        self.searchWord.insert(Tkinter.INSERT,"google search with python 3 tkinter")
        self.searchWord.place(x=10,y=15)

    def insert_text(self):
        GWord=self.searchWord.get(1.0,END)
        url="http://www.google.com/search?hl=en&q="+"+".join(GWord.split())
        req=urllib2.Request(url)
        req.add_header("User-Agent","Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) AppleWebKit/525.13 (KHTML, like Gecko) Chrome/0.2.149.29 Safari/525.13")
        GWord= urllib2.urlopen(req).read()
        self.txt.insert(Tkinter.INSERT,  GWord)

if __name__=="__main__":
    root=Tk()
    window(root)
    root.mainloop()

