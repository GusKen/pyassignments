

def getImageUrl(urlstring):
    import urllib
    connection=urllib.urlopen(urlstring)
    picture = connection.read()
    connection.close()
    curloc = picture.find("img")
    if curloc <> -1:
        picloc = picture.find("<src", curloc)
        picstart = picture.rfind(">",0,picloc)
        #writefile.open(picture,"wt")
        pic = open(picture, 'wb').read
        picture = urllib.urlopen(urlstring)
        pic.write(picture)
	pic.save(Photo)
        pic.close()
    else:
        print "There is no pictures in this URL"
getImageUrl('http://www.yahoo.com/')



