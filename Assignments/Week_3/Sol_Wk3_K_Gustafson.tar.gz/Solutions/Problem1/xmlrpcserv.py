#import SimpleXMLRPCServer
from SimpleXMLRPCServer import SimpleXMLRPCServer
import xmlrpclib, sys
from scipy import copy
import numpy as np
import scipy
import matplotlib.cm as cm
import pylab
import sys
import ftplib
from matplotlib import pyplot
import Image, ImageFilter, ImageEnhance
import matplotlib.image as mimage
#host,port ="localhost", 5020
#server =xmlrpclib.ServerProxy("http://%s:%d" % (host,port))
#proxy=xmlrpclib.ServerProxy("http://localhost:5020/")
#handle=open("fetched_Hall_transmit.jpg","w")
#handle.write(proxy.Hall_transmit().data)
#handle.close
class Some_Class_We_Want_Remotely_Accessible:
    def addition(self, a, b):
        return a + b
    def subtraction(self, a, b):
        return a - b
def Hallway():
	#ftp=ftplib.FTP("localhost")
	#ftp.login("anonymous", "meaningless")
	#ftp.cwd("P:\Assignments\Week_3\Solutions\Problem1\images\Hallway.jpg")
	#outfile=file("Picure.jpg","w")
	#ftp.retrlines("RETR c.jpg",lambda s, w=outfile.write: w(s+"\n"))
	#ims=mimage.imread("Picture.jpg")
	#with open("Hallway.jpg", "rb") as handle:
    #jp=pyplot.imread("Hallway.jpg")
    #Four=np.fft.fft2(jp)
    handle=open("Hallway.jpg", "rb")
    #handle = open("Hallway", "rb")
    return xmlrpclib.Binary(handle.read())
    handle.close()
	#ims=mimage.imread("images\Hallway.jpg")
	#return np.fft.fft2(ims)
	#outfile.close()
	#ftp.quit()
    
host, port = "localhost", 5020
#server = SimpleXMLRPCServer.SimpleXMLRPCServer((host, port),allow_none=True)
#server = SimpleXMLRPCServer((host, port),allow_none=True)
server = SimpleXMLRPCServer((host, port))
host1, port1 = "localhost", 5021
server = xmlrpclib.ServerProxy("http://%s:%d" % (host1, port1))
proxy= xmlrpclib.ServerProxy("http://localhost:5021/")

handle=open("fetched_Hall_transmit.jpg","wb")
handle.write(proxy.Hall_transmit().data)
handle.close

server = SimpleXMLRPCServer((host, port))
server.register_instance(Some_Class_We_Want_Remotely_Accessible())
server.register_multicall_functions()
server.register_function(Hallway,'Hallway')
server.register_introspection_functions()
print "XMLRPC Server is starting at:", host, port
server.serve_forever()

