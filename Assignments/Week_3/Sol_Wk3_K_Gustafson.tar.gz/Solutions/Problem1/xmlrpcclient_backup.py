import xmlrpclib, sys
host, port ="localhost" , 5020
server = xmlrpclib.ServerProxy("http://%s:%d" % (host, port))
available_methods = server.system.listMethods()
print " Available methods from server:"
for method in available_methods:
    print "\t" + method
result = server.subtraction(1,4)
print "Result:",result
result = server.addition(1,4)
print "Result:", result
