from SimpleXMLRPCServer import SimpleXMLRPCServer
from scipy import copy, random
import numpy as np
from pylab import *
from matplotlib import pyplot
import matplotlib.cm as cm
import matplotlib.pyplot as plt
import xmlrpclib, sys
import Image, ImageFilter, ImageEnhance
import matplotlib.image as mimage
#def Hall_transmit():
 #   handle=open("Hall_transmit.jpg","rb")
  #  return xmlrpclib.Binary(handle.read())
   # handle.close()
im=mimage.imread("images\Hallway.png")
#im = Image.open("images\Hallway.png")
#fig=plt.figure()
fig=plt.figure()
fig.subplots_adjust(hspace=0.1,wspace=0.1)
ax1=fig.add_subplot(221)
im1=ax1.imshow(im,cmap=cm.gray)
#im.show()
ip = pyplot.imread("images\Hallway.jpg")
#Fourier transform of image
#X=mimage.imread('images\Hallway.png')
ax2=fig.add_subplot(222)
F=np.fft.fft2(im)
im2=ax2.imshow(abs(F),)
fig2=figure(2)
im5 = imshow(abs(F),)
savefig('Four.png')
#im2.set_clim(0,300)
#show()
print ip.shape
#pyplot.imshow(ip[::-1])

Xf=np.fft.ifft2(F).real
ax3=fig.add_subplot(223)

im3=ax3.imshow(Xf,)

host, port ="localhost" , 5020
server = xmlrpclib.ServerProxy("http://%s:%d" % (host, port))
available_methods = server.system.listMethods()
print " Available methods from server:"
for method in available_methods:
    print "\t" + method
result = server.subtraction(1,4)
print "Result:",result
result = server.addition(1,4)
print "Result:", result
#Fserver= server.imagetransform()
proxy = xmlrpclib.ServerProxy("http://localhost:5020/")
handle = open("fetched_Hallway.jpg", "wb")
handle.write(proxy.Hallway().data)
handle.close()
def Hall_transmit():
    handle=open("Hall_transmit.jpg", "rb")
    return xmlrpclib.Binary(handle.read())
    handle.close()
ax4=fig.add_subplot(224)
lm4=mimage.imread("fetched_Hallway.jpg")
im4=ax4.imshow(lm4,)
#show()
host1, port1 = "localhost",5021
server = SimpleXMLRPCServer((host1,port1))
server.register_instance(())
server.register_multicall_functions()
server.register_function(Hall_transmit,'Hall_transmit')
server.register_introspection_functions()
print "XMLRPCClient-Server starting at :",host, port
show()
server.serve_forever()

