import SimpleXMLRPCServer
class Some_Class_We_Want_Remotely_Accessible:
    def addition(self, a, b):
        return a + b
    def subtraction(self, a, b):
        return a - b
host, port = "localhost", 5020
server = SimpleXMLRPCServer.SimpleXMLRPCServer((host, port),allow_none=True)
server.register_instance(Some_Class_We_Want_Remotely_Accessible())
server.register_multicall_functions()
server.register_introspection_functions()
print "XMLRPC Server is starting at:", host, port
server.serve_forever()

